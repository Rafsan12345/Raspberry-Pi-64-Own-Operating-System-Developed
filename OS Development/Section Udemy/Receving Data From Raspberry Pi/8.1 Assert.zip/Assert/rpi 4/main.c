#include "uart.h"
#include "print.h"
#include "debug.h"

void KMain(void)
{
    init_uart();
    printk("Hello, Raspberry pi\r\n");
    ASSERT(0);
    
    while (1) {
        ;
    }
}